import requests
from bs4 import BeautifulSoup
from datetime import datetime

def get_today_matches():
    url = "https://www.yallakora.com/match-center"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")

    matches = []
    match_cards = soup.find_all("div", class_="matchCard")

    for card in match_cards:
        competition = card.find("h2").get_text(strip=True)
        for match in card.find_all("li"):
            try:
                teamA = match.find("div", class_="teamA").get_text(strip=True)
                teamB = match.find("div", class_="teamB").get_text(strip=True)
                time = match.find("div", class_="MResult").get_text(strip=True)
                matches.append({
                    "competition": competition,
                    "teamA": teamA,
                    "teamB": teamB,
                    "time": time
                })
            except:
                continue
    return matches

def save_html(matches):
    now = datetime.now().strftime("%Y-%m-%d")
    with open("matches.html", "w", encoding="utf-8") as f:
        f.write(f"<html><head><meta charset='utf-8'><title>مباريات {now}</title></head><body>")
        f.write(f"<h1>مباريات اليوم ({now})</h1><ul>")
        for m in matches:
            f.write(f"<li>{m['competition']}: {m['teamA']} vs {m['teamB']} - {m['time']}</li>")
        f.write("</ul></body></html>")

if __name__ == "__main__":
    data = get_today_matches()
    save_html(data)